# Cancelled Before Activation

Run 36725521542, attempt1, job109921288686, Coref9ddc0f6 was cancelled while queued.
The runner was never started; provider and pool remained disabled throughout. No Core OIDC or
STS invocation occurred and no selected-work marker exists. This is preparation/readiness
evidence, not hosted STS acceptance, root semantic attestation or a provider gate closure.

MUSE's frozen packet review held activation with one P2: the packet lacks canonical verification
of the actual installed signed authority V2 snapshot and the Core-rederived STS operation target
against the complete V2 request and provider readback. Request/public installation identities
and builder linkage are correct but do not substitute for this required observation. Existing
pressure-builder CLI only emits regenerated authority payload; production target derivation is
private and there is no existing read-only installed verification CLI. Resolve this via the
canonical production paths, not hand-written crypto/parser/target assertions or a weaker bar.

MUSE also found a P3 in whole-journal export. The terminal observer was corrected before use:
raw journal bytes remain in a root-private temporary file and are removed; only closed boolean
facts and systemd exit/status metadata leave the host. Diagnostic lines and credential/environment
contents are never exported. Since the runner never started, no post-job cleanup result is proved.

Stopped-state observation: inactive/dead runner, PID0, empty runner cgroup, NRestarts0, no
job/execution-principal processes, no authority scopes or active-slot files, no public capture
record and no selected-work marker. Runner1379 was explicitly deregistered; group4 was deleted.
The VM, firewall, subnet and network were deleted. A subsequent read-only disk-after observation
lists no boot disk with the exact temporary VM name; it does not independently prove the original
autoDelete setting or deletion mechanism. WIF provider deletion
succeeded; provider lookup is NOT_FOUND after parent pool deletion. Pool is disabled and DELETED
(Google's soft-delete lifecycle, not a claim of permanent erasure). The retained after-state
arrays independently show no matching VM/network/firewall/subnet/group/runner. Historical
pool/provider/default network and other groups were not teardown targets.

Next gate: reviewed internal read-only installed-snapshot/operation-target verifier with no
network, replay consumption, reservation, installation mutation or execution authority. Freeze
and clear its new source gates, then use a fresh host/group/provider/request and new attempt.
Do not reuse this cancelled invocation or its consumed/expired installation. Step7 remains
active; IAM Credentials, Secret Manager, materialization, injection, selected work, Step8,
V12.2 and release remain outside this outcome. Pool IAM{} records only that pool policy check.

## Uncovered Material Behavior Inventory

- Contract-owned and proved: local source gates and canonical fresh stopped-runner provisioning;
  exact request/public-installation linkage and protected Listener identity, not live execution.
- Explicitly bounded in `outcome.json`: installed signed snapshot/runtime target comparison,
  OIDC/STS/provider operations, delivery, selected work, semantic attestation and cardinality.
- Repo-owned/external: GitHub server admission and Google control-plane enforcement are external;
  their configuration was observed, not exercised by this cancelled attempt. Ephemeral post-job
  cleanup and token disposal were not exercised.
- Named Ota gap: missing canonical read-only installed-snapshot/STS-operation preflight;
  owner is Core's internal pressure helper with production snapshot and operation-planning paths.
- Named inactive diagnostic follow-on: Launcher's managed-ancestor refusal omits the offending
  path (`pressure_provision::verify_existing_ancestor_chain_no_follow_from`); return during
  prepared-provisioning UX triage, without weakening its checks or widening this proof gate.
