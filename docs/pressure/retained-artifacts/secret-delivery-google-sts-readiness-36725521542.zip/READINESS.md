# Frozen STS Pre-start Packet

Prepared by SCOOBY on 2026-09-30. No provider or runner activation has occurred.

## Scope

One GitHub OIDC response and one accepted Google STS response, token discarded, terminal
refusal before IAM Credentials, Secret Manager, materialization, injection or selected work.
No release, Step 8 or V12.2. Job-observed results are not root semantic attestation.

## Frozen Invocation

- Core: f9ddc0f67b52031cdf16d017b405c3783de56ced.
- Launcher runtime: dd667c3d6b63d8d26d9e2a40f831e9d08a7a6864.
- Protocol: e5fe1c83e562e02f60e27026c7148918bd016155.
- Actions workflow ID 371186494, run 36725521542, attempt 1, job 109921288686, queued.
- Dispatcher actor ID 14136806; repository ID 1188051251; owner ID 270006511.
- Workflow ref: ota-run/ota/.github/workflows/secret-delivery-google-sts-live.yml@refs/heads/1.6.29-implementation.
- Runner.Listener 2.337.0, runner ID 1379, offline, group 4 ota-sts-20260930.

## Observation Files

- `run-queued.json`, `jobs-queued.json`: GitHub API observations.
- `runner-group-observed.json`, `runner-group-repositories.json`, `runner-group-runners.json`,
  `runner-observed.json`: exact repository/full-SHA workflow admission and offline runner.
  Public runner GET does not expose independent server ephemeral/update flag readback.
  Root-operated registration submitted --ephemeral --disableupdate and the protected local
  .runner projection records both true; GitHub documents the server-side one-job semantics.
- `secret-delivery-pressure-request.json`: complete V2 request mirror. Installed original is
  root:root mode0400 singular file; JCS request identity is
  sha256:569b3fc8b448d3d5cd6aa11d9cd6dc9d999bef0a3f4cd7ffd094594fec2bcc57.
- `provider-exact-disabled.json`, `pool-disabled.json`, `pool-iam-policy.json`: disabled fresh
  provider/pool, exact issuer/audience/mapping and invocation condition; no pool IAM policy.
  HTTPS JWT audience and //iam.googleapis.com STS audience remain distinct.
- `installation-observed.txt`: complete public installation and artifact identities, root
  request identity rederivation, effective canonical runner unit/drop-ins, exact three writable
  paths, no job/execution processes, capture units, configuration integrity hashes/modes without
  contents, and production Listener verifier as job principal (2.337.0).
- `host-observed.json`: new short-lived Linux/X64 VM, no service account/scopes, max2h auto-delete.

Canonical provisioning succeeded at 14:06:50Z with a fresh-state observation. Public installation
identity: sha256:ba03799e5ee919adfe47dd3d263f93d3089ad1c8812ef5bc5777810cd1850f0c.
Pressure installation identity: sha256:dac841903d1f6b6f3ae8bdc7ff4dd0d6f424edd07f2d15ba1e499846a3d48f71.
Preparation first refused archive-preserved UID1001 at the runner root, then the prematurely
created empty capture source directory. Both were corrected before authority installation;
the canonical provisioner's successful fresh-state observation is retained, not inferred from
offline registration. No permission boundary was relaxed. The same queued attempt has not run.

## Retention And Teardown

Keep unit argv unchanged; root-owned credential/config files remain0640 and outside writable
paths. The ephemeral runner's post-job local config deletion may fail under ProtectSystem=strict.
Record that separately; do not call its completion signal successful job proof. Do not restart,
re-register, or reuse consumed state. If job/capture/terminal evidence is incomplete, retain that
as incomplete/failure. Capture is provider-free custody and does not attest STS semantics.

After reviewed activation, retain the exact job log/closed posture and administrator-observed
provider configuration, public installation, root capture records if any, runner unit exit and
sanitized diagnostic facts. Never retain JWT/bearer/token or private credentials. Stop the runner,
verify no principal processes/cgroup, observe deregistration (delete1379 if still present), disable
provider and pool, then delete only the new VM, group4, provider/pool, firewall/subnet/network.
Observe deletion including soft-deleted WIF state. Auto-delete is only a backstop. The historical
pool/provider/default VPC and previous groups are not teardown targets. `teardown.sh` owns only
the named newly created infrastructure; explicit runner stop/deregistration precedes it.
