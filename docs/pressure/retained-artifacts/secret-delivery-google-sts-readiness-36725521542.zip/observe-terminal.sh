#!/bin/bash
set -euo pipefail
test "$(id -u)" = 0
systemctl stop ota-authority-pressure-runner.service
printf '%s\n' '=== TERMINAL RUNNER UNIT ==='
systemctl show ota-authority-pressure-runner.service --no-pager \
  --property=ActiveState --property=SubState --property=MainPID --property=ControlGroup \
  --property=Result --property=ExecMainCode --property=ExecMainStatus --property=NRestarts
printf '%s\n' '=== CLOSED RUNNER JOURNAL FACTS ==='
umask 077
journal="$(mktemp /root/ota-runner-journal.XXXXXX)"
trap 'rm -f "$journal"' EXIT
journalctl -u ota-authority-pressure-runner.service --no-pager -o cat >"$journal"
if grep -Eq 'Read-only file system|Access to the path .* is denied' "$journal"; then
  printf '%s\n' 'journal_read_only_or_denied_text_observed=true'
else
  printf '%s\n' 'journal_read_only_or_denied_text_observed=false'
fi
printf '%s\n' '=== CLOSED RUNNER DIAGNOSTIC FACTS ==='
if grep -hEq 'Job has finished at backend' /opt/ota-actions-runner/_diag/Runner_*.log; then
  printf '%s\n' 'listener_completion_text_observed=true'
else
  printf '%s\n' 'listener_completion_text_observed=false'
fi
if grep -hEq 'Read-only file system|Access to the path .* is denied' /opt/ota-actions-runner/_diag/Runner_*.log; then
  printf '%s\n' 'listener_read_only_or_denied_text_observed=true'
else
  printf '%s\n' 'listener_read_only_or_denied_text_observed=false'
fi
printf '%s\n' '=== ROOT PUBLIC CAPTURE RECORDS ==='
find /var/lib/ota/authority-launcher-public/hosted-evidence-captures -maxdepth 1 -type f -name '*.json' -print
printf '%s\n' '=== TERMINAL AUTHORITY SCOPES ==='
systemctl list-units --all --type=scope --no-legend --no-pager
printf '%s\n' '=== ACTIVE SLOT FILES ==='
find /var/lib/ota/authority-launcher/active -maxdepth 1 -type f -print
printf '%s\n' '=== PRINCIPAL PROCESS ABSENCE ==='
if pgrep -u ota-authority-job,ota-authority-exec; then
  exit 1
fi
test "$(systemctl show ota-authority-pressure-runner.service --property=MainPID --value)" = 0
test -z "$(systemctl show ota-authority-pressure-runner.service --property=ControlGroup --value)"
test ! -e /srv/ota-v3-pressure/selected-work-executed
printf '%s\n' 'RUNNER_STOPPED_NO_PRINCIPAL_PROCESS_NO_SELECTED_MARKER'
